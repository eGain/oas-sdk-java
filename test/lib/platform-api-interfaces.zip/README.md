# eGain: Platform - API Interfaces
Open API specifications for all Web APIs in the eGain Platform.

# Redocly Deployment
API definitions may be published to one of several redocly environments to be made available on the appropriate developer portal. The available environments are:

## Development (dev)

Portal URL: <a href="https://developer-dev.ezdev.net" target="_blank">https://developer-dev.ezdev.net</a>

Environment Variables:

| Variable  | Value |
| ------------- | ------------- |
| API_DOMAIN  | api-dev.ezdev.net  |
| LOGIN_DOMAIN  | logindev.ezdev.net  |
| DOMAIN_HINT  | tenant1users.ezdev.net  |
| AUTHORIZATION_CODE_CLIENT_ID  | b83cc54d-0be1-4c48-8856-a4962a350380  |
| SCOPE_PREFIX  | https://api-dev.ezdev.net/auth/  |
| CLIENT_CREDENTIALS_CLIENT_ID  | d85aaf6d-2509-4ec3-b6ee-1caf1e2743a5 |
| GATEWAY_ID  | b1ba1724-ff95-469d-882f-f2fb6a3ddddb  |
| TENANT_ID  | TMPROD11111111  |

Changes are pushed to the dev branch of the redocly API registry on any push to the master branch.

## Quality Engineering (qe)

Portal URL: <a href="https://developer-qe.ezdev.net" target="_blank">https://developer-qe.ezdev.net</a>

Environment Variables:

| Variable  | Value |
| ------------- | ------------- |
| API_DOMAIN  | api-qe.ezdev.net  |
| LOGIN_DOMAIN  | login-qe.ezdev.net  |
| DOMAIN_HINT  | ussuhvin0780.ezdev.net  |
| AUTHORIZATION_CODE_CLIENT_ID  | 027308a0-46c8-4f42-af9e-207025e64dad  |
| SCOPE_PREFIX  | https://api-qe.ezdev.net/auth/  |
| CLIENT_CREDENTIALS_CLIENT_ID  | 374bfd14-4a3f-43f0-8cf8-c337751966ea |
| GATEWAY_ID  | a51d6b19-0629-4413-8e04-870a12029391  |
 
Changes are pushed to the qe branch of the redocly API registry on the creation of a new tag.

## Production (prod)

Portal URL: <a href="https://apidev.egain.com" target="_blank">https://apidev.egain.com</a>

Environment Variables:

| Variable  | Value |
| ------------- | ------------- |
| API_DOMAIN  | api.egain.cloud  |
| LOGIN_DOMAIN  | login.egain.cloud  |
| DOMAIN_HINT  | eg5012qa31l.egain.cloud  |
| AUTHORIZATION_CODE_CLIENT_ID  | 7c56d185-0515-437f-bb46-970d2d775ab5  |
| SCOPE_PREFIX  | https://api.egain.cloud/auth/  |
| CLIENT_CREDENTIALS_CLIENT_ID  | bb7b6e0e-9c01-4137-9657-bab8513e35b0 |
| GATEWAY_ID  | b0a39921-9dae-4fcd-940d-6f206a80a0f8  |
      
Changes are pushed to the prod branch of the redocly API registry on the creation of a new release.
