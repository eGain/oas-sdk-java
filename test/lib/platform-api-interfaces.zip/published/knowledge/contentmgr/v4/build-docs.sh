#!/bin/bash

# Knowledge Content Manager v4 Documentation Generator
# This script generates Redocly documentation with SLA information included
# without modifying the original api.yaml file

set -e

echo "📚 Knowledge Content Manager v4 Documentation Generator"
echo "======================================================="

# Configuration
API_FILE="api.yaml"
SLA_FILE="sla.yaml"
OUTPUT_DIR="dist"
OUTPUT_FILE="contentmgr-v4-api.html"
TEMP_API_FILE=".api-with-sla.yaml"

# Check if required files exist
if [ ! -f "$API_FILE" ]; then
    echo "❌ Error: $API_FILE not found"
    exit 1
fi

if [ ! -f "$SLA_FILE" ]; then
    echo "❌ Error: $SLA_FILE not found"
    exit 1
fi

# Create output directory if it doesn't exist
mkdir -p "$OUTPUT_DIR"

echo ""
echo "📄 Processing files..."
echo "   API File: $API_FILE"
echo "   SLA File: $SLA_FILE"
echo ""

# Generate temporary API file with SLA information merged
echo "🔄 Merging SLA information into API documentation..."

node <<'EOF'
const fs = require('fs');
const yaml = require('js-yaml');

// Read the files
const apiContent = fs.readFileSync('api.yaml', 'utf8');
const slaContent = fs.readFileSync('sla.yaml', 'utf8');

// Parse SLA YAML
const sla = yaml.load(slaContent);

// Extract SLA information and format it
const performanceSection = `
    ## Service Level Agreement (SLA)
    
    ### Performance Metrics
    
    #### Response Times
    | Operation | P50 | P95 | P99 |
    |-----------|-----|-----|-----|
    | Import Job Creation | ${sla.nfr.performance.response_times.import_job_creation.p50} | ${sla.nfr.performance.response_times.import_job_creation.p95} | ${sla.nfr.performance.response_times.import_job_creation.p99} |
    | Validation Job Creation | ${sla.nfr.performance.response_times.validation_job_creation.p50} | ${sla.nfr.performance.response_times.validation_job_creation.p95} | ${sla.nfr.performance.response_times.validation_job_creation.p99} |
    | Job Status Check | ${sla.nfr.performance.response_times.job_status_check.p50} | ${sla.nfr.performance.response_times.job_status_check.p95} | ${sla.nfr.performance.response_times.job_status_check.p99} |
    
    #### Processing Times
    | Content Volume | Import Operations | Validation Operations |
    |---------------|-------------------|----------------------|
    | Small (< 1,000 articles) | ${sla.nfr.performance.processing_times.import_operations.small_jobs} | ${sla.nfr.performance.processing_times.validation_operations.small_content} |
    | Medium (1,000-10,000 articles) | ${sla.nfr.performance.processing_times.import_operations.medium_jobs} | ${sla.nfr.performance.processing_times.validation_operations.medium_content} |
    | Large (> 10,000 articles) | ${sla.nfr.performance.processing_times.import_operations.large_jobs} | ${sla.nfr.performance.processing_times.validation_operations.large_content} |
    
    ### Service Plans & Rate Limits
    
    #### Starter Plan
    - **Rate Limit**: ${Math.round(sla.plans.starter.rates.default.post.requests[0].max * 60)} requests/minute
    - **Burst**: Up to ${sla.plans.starter.rates.default.post.burst[0].max} concurrent requests
    - **Monthly Quota**: ${sla.plans.starter.quotas.default.post.requests[0].max.toLocaleString()} requests/month
    - **Concurrent Jobs**: ${sla.nfr.performance.throughput.concurrent_jobs.starter}
    
    #### Growth Plan
    - **Rate Limit**: ${Math.round(sla.plans.growth.rates.default.post.requests[0].max * 60)} requests/minute
    - **Burst**: Up to ${sla.plans.growth.rates.default.post.burst[0].max} concurrent requests
    - **Monthly Quota**: ${sla.plans.growth.quotas.default.post.requests[0].max.toLocaleString()} requests/month
    - **Concurrent Jobs**: ${sla.nfr.performance.throughput.concurrent_jobs.growth}
    
    #### Enterprise Plan
    - **Rate Limit**: ${Math.round(sla.plans.enterprise.rates.default.post.requests[0].max * 60)} requests/minute
    - **Burst**: Up to ${sla.plans.enterprise.rates.default.post.burst[0].max} concurrent requests
    - **Monthly Quota**: ${sla.plans.enterprise.quotas.default.post.requests[0].max.toLocaleString()} requests/month
    - **Concurrent Jobs**: ${sla.nfr.performance.throughput.concurrent_jobs.enterprise}
    
    #### Internal Plan
    - **Rate Limit**: ${Math.round(sla.plans.internal.rates.default.post.requests[0].max * 60)} requests/minute
    - **Burst**: Up to ${sla.plans.internal.rates.default.post.burst[0].max} concurrent requests
    - **Monthly Quota**: ${sla.plans.internal.quotas.default.post.requests[0].max.toLocaleString()} requests/month
    - **Concurrent Jobs**: ${sla.nfr.performance.throughput.concurrent_jobs.internal}
    
    ### Security
    - **Authentication**: ${sla.nfr.security.authentication.method}
    - **Token Lifetime**: ${sla.nfr.security.authentication.token_lifetime} (access token), ${sla.nfr.security.authentication.refresh_token_lifetime} (refresh token)
    - **Encryption in Transit**: ${sla.nfr.security.data_protection.encryption_in_transit}
    - **Encryption at Rest**: ${sla.nfr.security.data_protection.encryption_at_rest}
    - **Data Retention**: ${sla.nfr.security.compliance.data_retention}
    - **Audit Logging**: ${sla.nfr.security.compliance.audit_logging ? 'Enabled' : 'Disabled'}
    - **Required Scopes**: \`${sla.nfr.security.authorization.required_scopes.join(', ')}\`
    `;

// Find the description section and insert SLA information before "## License Requirements"
const licenseMarker = '## License Requirements';
const insertPosition = apiContent.indexOf(licenseMarker);

if (insertPosition === -1) {
    console.error('❌ Error: Could not find "## License Requirements" in api.yaml');
    process.exit(1);
}

// Insert the SLA section
const modifiedContent = apiContent.slice(0, insertPosition) + performanceSection + '\n    ' + apiContent.slice(insertPosition);

// Write the temporary file
fs.writeFileSync('.api-with-sla.yaml', modifiedContent);

console.log('✅ SLA information merged successfully');
EOF

# Generate documentation using Redocly CLI
echo ""
echo "🔨 Generating documentation with Redocly CLI..."
npx --yes @redocly/cli build-docs "$TEMP_API_FILE" -o "$OUTPUT_DIR/$OUTPUT_FILE"

# Clean up temporary file
echo ""
echo "🧹 Cleaning up temporary files..."
rm -f "$TEMP_API_FILE"

# Get file size
FILE_SIZE=$(du -h "$OUTPUT_DIR/$OUTPUT_FILE" | cut -f1)

echo ""
echo "✅ Documentation generated successfully!"
echo "======================================================="
echo "📁 Output: $OUTPUT_DIR/$OUTPUT_FILE ($FILE_SIZE)"
echo "🌐 Open the file in your browser to view the documentation"
echo ""

