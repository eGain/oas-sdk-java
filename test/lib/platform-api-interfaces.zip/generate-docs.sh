#!/bin/bash

# eGain Platform API Documentation Generator
# This script generates Redocly documentation for all configured APIs

echo "🚀 Starting eGain Platform API documentation generation..."

# Create docs directory if it doesn't exist
mkdir -p docs

# Generate documentation for each API
echo "📚 Generating Content Manager v4 documentation..."
npx @redocly/cli build-docs published/knowledge/contentmgr/v4/api.yaml -o docs/contentmgr-v4.html

echo "📚 Generating Conversation Manager v3 documentation..."
npx @redocly/cli build-docs published/conversation/conversationmgr/v3/api.yaml -o docs/conversationmgr-v3.html

echo "📚 Generating Case Manager v3 documentation..."
npx @redocly/cli build-docs published/core/casemgr/v3/api.yaml -o docs/casemgr-v3.html

echo "📚 Generating Authentication Manager v3 documentation..."
npx @redocly/cli build-docs published/core/authmgr/v3/api.yaml -o docs/authmgr-v3.html

echo "📚 Generating Customer Manager v3 documentation..."
npx @redocly/cli build-docs published/core/customermgr/v3/api.yaml -o docs/customermgr-v3.html

echo "📚 Generating Department Manager v3 documentation..."
npx @redocly/cli build-docs published/core/departmentmgr/v3/api.yaml -o docs/departmentmgr-v3.html

echo "📚 Generating File Manager v3 documentation..."
npx @redocly/cli build-docs published/core/filemgr/v3/api.yaml -o docs/filemgr-v3.html

echo "📚 Generating User Manager v3 documentation..."
npx @redocly/cli build-docs published/core/usermgr/v3/api.yaml -o docs/usermgr-v3.html

echo "📚 Generating Portal Manager v4 documentation..."
npx @redocly/cli build-docs published/knowledge/portalmgr/v4/api.yaml -o docs/portalmgr-v4.html

echo "📚 Generating Integration Manager v4 documentation..."
npx @redocly/cli build-docs published/core/integrationmgr/v4/api.yaml -o docs/integrationmgr-v4.html

echo "📚 Generating AI Services v4 documentation..."
npx @redocly/cli build-docs published/core/aiservices/v4/api.yaml -o docs/aiservices-v4.html

echo "✅ Documentation generation complete!"
echo "📁 Generated files are in the 'docs' directory"
echo "🌐 Open 'docs/index.html' to view all documentation"
